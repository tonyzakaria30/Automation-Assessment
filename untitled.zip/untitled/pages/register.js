 
 
 
 export class register {
 
  // Locators 

  
  next_button = '//button[@type="submit"]'
  company_name = '//input[@name="companyName"]'
  company_Tax = '//input[@name="taxNumber"]'
  user_name = '//input[@name="firstName"]'
  family_name = '//input[@name="familyName"]'
  phone_number = '//input[@name="phoneNumber"]'
  password = '//input[@name="password"]'
  otp = '//input[@name="otp"]'
  assertion_registeration = '//div[@class="mt-4 mb-3"]/p'
  phone_error = '(//div[@class="mt-1"]/p)[2]'
  
  // Methods

         
         clickOnNext()
         {
          cy.xpath(this.next_button).click();
         }
   
         typeCompanyName()
         {
           cy.xpath(this.company_name).type("company");
         }
   
         typeCompanyTax ()
         {
           cy.xpath(this.company_Tax).type("123123123");
         }

         typeUserName(userName)
        {
          cy.xpath(this.user_name).type(userName);
        }

        typeFamilyName(familyName)
        {
          cy.xpath(this.family_name).type(familyName);
        }

        typePhoneNumber(phonNumber)
        {
        cy.xpath(this.phone_number).type(phonNumber);
        } 
        
        typePassword(passWord)
        {
          cy.xpath(this.password).type(passWord);
        }
        
        typeOtp(otp)
        {
          cy.xpath(this.otp).type(otp);
        }

        assertOnRegisteration()
        {
          cy.xpath(this.assertion_registeration).should('have.text', 'هيجيلك كود من 6 أرقام لتأكيد رقم الموبايل');
        }

        assertOnPhoneError()
        {
           cy.xpath(this.phone_error).should('have.text', 'الرقم مسجل بالفعل');
        }
   
   }
   export default new register (); 